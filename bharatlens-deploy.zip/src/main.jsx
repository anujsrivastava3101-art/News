import React from 'react'
import ReactDOM from 'react-dom/client'
import BharatLens from './App.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BharatLens />
  </React.StrictMode>,
)
